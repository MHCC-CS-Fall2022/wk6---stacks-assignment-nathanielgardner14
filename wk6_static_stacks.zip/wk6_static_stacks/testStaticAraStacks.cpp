// Filename: testStaticAraStacks.cpp
// Created by: Nathaniel Gardner
// Driver file for a static array stack class. Functions created output the contents of 
// integer stacks and compare if two instances of stacks are the same.

#include <iostream> // cout, cin
#include "stack1.h" // static array stacks class
using namespace std;
using namespace staticStack_ngardner;

// Driver file prototypes:
void fillStack(stack<int>&);
// Fills the stack with user input integers. User determines the number of integers
// put into the stack.

void showBottomToTop(stack<int>&);
// Puts the stack values into an array and outputs the values beginning at the bottom 
// (first value input). Once finished the integers are put back in the stack in the
// original order.

bool compareStacks(stack<int>&, stack<int>&);
// Evaluates whether or not two stacks hold the same values and are in the same order.
// If the stacks are different sizes function returns false immediately. Otherwise,
// the function goes through and evaluates if they are the same. If yes, it returns true
// but if they are not the same then it returns false.

int main()
{
	stack<int> firstNums, secondNums;
	
	cout << "Input the information for a set of numbers.\n";
	fillStack(firstNums);
	showBottomToTop(firstNums);
	cout << "\n\nInput the information for a second set of numbers.\n";
	fillStack(secondNums);
	showBottomToTop(secondNums);
	if (compareStacks(firstNums, secondNums) == true)
		cout << "\n\nThe two sets have the same values in the same order.\n";
	else
		cout << "\n\nThe two sets do not have the same values in the same order.\n";
	return 0;
}

void fillStack(stack<int>& numSet)
{
	int userInput, userAmount;
	
	do
	{
		cout << "How many numbers do you want to insert into the set? ";
		cin >> userAmount;
		if (userAmount > 30 || userAmount < 0)
		{
			cout << "The maximum size for this list of numbers is 30\n"
			     << "Please input something 30 or below.\n";
		}
	} while (userAmount > 30 || userAmount < 0); // Capacity of Stack == 30
	for (int i = 0; i < userAmount; i++)
	{
		cout << "Input a number: ";
		cin >> userInput;
		numSet.push(userInput);
	}	
	return;	
}

void showBottomToTop(stack<int>& numSet)
{
	int setSize = numSet.size();
	int i;
	int tempSet[setSize];
	
	i = 0;
	while(numSet.size() != 0)
	{
		tempSet[i] = numSet.top();
		i++;
		numSet.pop();
	}
	
	for (i = setSize-1; i >= 0; i--)
		cout << tempSet[i] << " ";

	for (i = setSize-1; i >= 0; i--)
		numSet.push(tempSet[i]);
	return;
}

bool compareStacks(stack<int>& numSet1, stack<int>& numSet2)
{
	stack<int> tempStack1, tempStack2;
	bool equalSets = true;	
	
	if (numSet1.size() != numSet2.size())
		return false;
		
	while (numSet1.size() != 0 && equalSets == true)
	{
		if (numSet1.top() != numSet2.top())
			equalSets = false;
		tempStack1.push(numSet1.top());
		numSet1.pop();
		tempStack2.push(numSet2.top());
		numSet2.pop();
	}
	
	while(tempStack1.size() != 0)
	{
		numSet1.push(tempStack1.top());
		tempStack1.pop();
	}
	
	while(tempStack2.size() != 0)
	{
		numSet2.push(tempStack2.top());
		tempStack2.pop();
	}
	if (equalSets == false)
		return false;
	return true;
}

