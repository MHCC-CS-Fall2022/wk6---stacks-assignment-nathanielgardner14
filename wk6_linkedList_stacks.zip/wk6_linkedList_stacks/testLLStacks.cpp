// Filename: testLLStacks.cpp
// Created by: Nathaniel Gardner
// Driver file for a stack class that utilizes a linked list. Program fills two stacks with
// user given integers, outputs the contents of the two stacks, and compares them.

#include <iostream> // cin, cout
#include "stack2.h" // linked list stacks class, node class
using namespace std;
using namespace main_savitch_6B;

// Driver file prototypes
void fillStack(stack<int>&);
// Fills the stack with integers chosen by the user. The number of integers input is also
// user determined.

void showBottomToTop(stack<int>&);
// Pops each value from the stack into an array. Then it outputs the data of the array
// beginning with the value first input by the user (also known as bottom to top).
// Then the values are reinserted into the stack.

bool compareStacks(stack<int>&, stack<int>&);
// Evaluates if two stacks have the same values in the same order. First, if the size
// of the two stacks is different it returns false immediately. Otherwise the function
// goes through checking if the stack values are the same. Returns true if they are, 
// false if not.

int main()
{
	stack<int> firstNums, secondNums;
	
	cout << "Input the information for a set of numbers.\n";
	fillStack(firstNums);
	showBottomToTop(firstNums);
	cout << "\n\nInput the information for a second set of numbers.\n";
	fillStack(secondNums);
	showBottomToTop(secondNums);
	if (compareStacks(firstNums, secondNums) == true)
		cout << "\n\nThe two sets have the same values in the same order.\n";
	else
		cout << "\n\nThe two sets do not have the same values in the same order.\n";
	return 0;
}

void fillStack(stack<int>& numSet)
{
	int userInput, userAmount;
	
	cout << "How many numbers do you want to insert into the set? ";
	cin >> userAmount;
	for (int i = 0; i < userAmount; i++)
	{
		cout << "Input a number: ";
		cin >> userInput;
		numSet.push(userInput);
	}	
	return;	
}

void showBottomToTop(stack<int>& numSet)
{
	int setSize = numSet.size();
	int i;
	int tempSet[setSize];
	
	i = 0;
	while(numSet.size() != 0)
	{
		tempSet[i] = numSet.top();
		i++;
		numSet.pop();
	}
	
	for (i = setSize-1; i >= 0; i--)
		cout << tempSet[i] << " ";

	for (i = setSize-1; i >= 0; i--)
		numSet.push(tempSet[i]);
	return;
}

bool compareStacks(stack<int>& numSet1, stack<int>& numSet2)
{
	stack<int> tempStack1, tempStack2;
	bool equalSets = true;	
	
	if (numSet1.size() != numSet2.size())
		return false;
		
	while (numSet1.size() != 0 && equalSets == true)
	{
		if (numSet1.top() != numSet2.top())
			equalSets = false;
		tempStack1.push(numSet1.top());
		numSet1.pop();
		tempStack2.push(numSet2.top());
		numSet2.pop();
	}
	
	while(tempStack1.size() != 0)
	{
		numSet1.push(tempStack1.top());
		tempStack1.pop();
	}
	
	while(tempStack2.size() != 0)
	{
		numSet2.push(tempStack2.top());
		tempStack2.pop();
	}
	if (equalSets == false)
		return false;
	return true;
}

